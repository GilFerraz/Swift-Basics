//: Playground - noun: a place where people can play

import UIKit

// 1. Write a function named min2 that takes two Int values, a and b, and returns the smallest one.
func min2(_ a : Int, _ b : Int) -> Int
{
    return (a > b) ? a : b;
}

// 2. Write a function that takes an Int and returns it's last digit. Name the function lastDigit.
func lastDigit(_ value : Int) -> Int
{
    return value % 10;
}

// 3. Write a function named first that takes an Int named N and returns an array with the first N numbers starting from 1.

// 4. Write a function named "countdown" that takes a number N.
//    The function should print the numbers from N to 1 with a one second pause in between and the write "GO!" in the end.
//    To make the computer wit for one second, call the "sleep" function from the standard library.
//    The sleep function takes one parameter, the number of seconds to sleep.
func countdown(_ n : Int)
{
    var i = n;
    
    while (i > 1)
    {
        print(i);
        i -= 1;
        
        sleep(1);
    }
    
    print("Go!");
}

// 5. Print all the elements from one array that appear in other (intersection).

var list1 = [1, 2, 3, 4, 10, 100];
var list2 = [1, 2, 3, 4, 5, 6];
// list1 && list2 = [1, 2, 3, 4]

func intersection(_ a : [Int], _ b : [Int]) -> [Int]
{
    var result = [Int]()
    
    let largest = (a.count > b.count) ? a : b;
    let smallest = (a.count > b.count) ? b : a;
    
    var i = 0;
    for s in smallest
    {
        if (s == largest[i])
        {
            print(s);
            result.append(s);
        }
        
        i += 1;
    }
    
    return result;
}

//intersection(list1, list2);

// 6. Generate the first "n" numbers in the fibonacci sequence. Store them in an array named fibonacci and print them one on each line.
func iterativeFibonacci(_ n : Int) -> [Int]
{
    var first = 0;
    var second = 1;
    var next = 0;
    
    var fibonacci = [Int]();
    
    for i in 0 ..< n
    {
        if (i <= 1)
        {
            next = i;
        }
        else
        {
            next = first + second;
            first = second;
            second = next;
        }
        
        print(next);
        fibonacci.append(next);
        
    }
    
    return fibonacci;
}

iterativeFibonacci(10)

// 7. Create a list unique with all the unique numbers from a given array, and then print the numbers on separate lines.
var list3 = [1, 1, 3, 5, 6, 3, 7, 5]

func unique(_ list : [Int]) -> [Int]
{
    var result : [Int] = [];
    
    for value in list
    {
        var isUnique = true;
        
        for r in result
        {
            if (value == r)
            {
                isUnique = false;
            }
        }
        
        if (isUnique)
        {
            result.append(value);
        }
    }
    
    return result;
}

unique(list3);

// 8. Sort the values in a given array in descending order.
list3.sort(by: >);


