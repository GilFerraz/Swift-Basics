import UIKit

class Cellar
{
    var name : String;
    var wines : [Wine];
    var transactions : [Transaction];
    
    init(name: String)
    {
        self.name = name;
        self.wines = [];
        self.transactions = [];
    }
    
    func GetPayedTransactions(year: Int) -> [Transaction]
    {
        
    }
}

class Wine
{
    var id : Int;
    var name : String;
    var year : Int;
    var producer : String;
    var price : Float;
    
    init(name: String, year: Int, producer: String, price: Float)
    {
        self.id = name.hashValue;
        self.name = name;
        self.year = year;
        self.producer = producer;
        self.price = price;
    }
}

class Transaction
{
    private var date : Date;
    private var wines : [Wine];
    var value : Float;
    private var paymentState : PaymentState;
    private var paymentType : PaymentType;
    
    init()
    {
        self.date = Date();
        self.wines = [];
        self.value = 0.0;
        self.paymentState = PaymentState.NotPayed;
        self.paymentType = PaymentType.Money;
    }
    
    func AddWine(wine: Wine)
    {
        wines.append(wine);
        value += wine.price;
    }
}

enum PaymentState
{
    case Payed
    case NotPayed
}

enum PaymentType
{
    case Money
    case CreditCard
}

var cellar = Cellar(name: "Gil's Cellar");

var aWine = Wine(name: "Os Velhotes", year: 2008, producer: "Wines & Co.", price: 19.99);
var transaction = Transaction();
transaction.AddWine(wine: aWine);
transaction.AddWine(wine: aWine);

print(transaction.value);
