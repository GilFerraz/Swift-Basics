import UIKit

class Stack
{
    var stack : [Int];
    
    init()
    {
        self.stack = [Int]();
    }
    
    func Push(value: Int)
    {
        stack.append(value);
    }
    
    func Pop() -> Int?
    {
        return self.IsEmpty() ? nil : stack.removeLast();
    }
    
    func Peek() -> Int?
    {
        return stack.first;
    }
    
    func IsEmpty() -> Bool
    {
        return stack.count == 0;
    }
}

var aStack : Stack = Stack();

aStack.Pop();

aStack.Push(value: 1);
aStack.Push(value: 2);
aStack.Push(value: 3);

aStack.Peek();
aStack.Pop();

aStack.IsEmpty();
