//: Playground - noun: a place where people can play

import UIKit

// 1. Declare a variable called "one" that holds the value.
//var one : Int = 1
var one : Float = 1

// 2. Change "one"'s value to 4.
one = 4

// 3. Change "one"'s value to 1.2 (you might need to change "one"'s declaration first.
one = 1.2

// 4. Declare a variable called "string" that holds the value "my string".
var string : String = "my string"

// 5. Print the length of "string".
print(string.characters.count)

// 6. Print the first character of "string".
print(string[string.startIndex])

// 7. Print the 4th character in "string".
print(string[string.index(string.startIndex, offsetBy: 3)])

// 8. Print the first 3 characters in "string".
print(print(string[string.index(string.startIndex, offsetBy: 0 ..< 3)]))

// 9. Print the last 3 characters in "string".


// 10. Print the last 3 characters in "string", reversed.


// 11. Print the 2nd word in "string".


// 12. Create a string that contains the values of "one" and "string" variables.


// 13. Create an array that contains "a", "b", "c", called "myArray".
var myArray : [String] = ["a", "b", "c"]

// 14. Get the length of myArray.
print(myArray.count)

// 15. Get the 2nd item in myArray.
print(myArray[2])

// 16. Print "long" if the length of myArray is more than 5, else print "short".
if myArray.count > 5
{
    print("long")
}
else
{
    print("short")
}

// 17. Print each element in the array on a line by itself.
for e in myArray
{
    print(e)
}

for i in 0 ..< myArray.count
{
    print(myArray[i])
}

var i = 0
while(i < myArray.count)
{
    print(myArray[i])
    i += 1
}

// 18.
let myStrings = ["these", "are", "my", "strings"];

// 19.
//myStrings.append("constant")

// 20. 


// 21.
if myStrings.contains("my")
{
    print(myStrings.index(of: "my")!)
}

if let x = myStrings.index(of: "mys")
{
    print(x);
}

//
func lastDigit(_ n : Int) -> Int
{
    return n % 10;
}

// 
func first(_ n : Int)
{
    
}

